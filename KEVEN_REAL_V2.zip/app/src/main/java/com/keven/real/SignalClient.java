package com.keven.real;

import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import org.json.JSONObject;

public class SignalClient {
    public interface Listener { void onMessage(JSONObject o); void onStatus(String s); }
    private final Listener listener; private WebSocket ws;
    public SignalClient(Listener l){listener=l;}
    public void connect(String url){
        new Thread(() -> {
            try {
                URI u=new URI(url);
                ws=new WebSocket(u, listener);
                ws.run();
            } catch(Exception e){ listener.onStatus("ERROR: "+e.getMessage());}
        }).start();
    }
    public void send(JSONObject o){ if(ws!=null) ws.send(o.toString()); }

    static class WebSocket {
        Socket s; BufferedReader in; BufferedWriter out; Listener l;
        WebSocket(URI u, Listener li)throws Exception{
            l=li; int port=u.getPort()>0?u.getPort():80;
            s=new Socket(u.getHost(),port);
            out=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),"UTF-8"));
            in=new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8"));
            String key=java.util.Base64.getEncoder().encodeToString(new byte[16]);
            out.write("GET "+(u.getPath().isEmpty()?"/":u.getPath())+" HTTP/1.1\r\nHost: "+u.getHost()+"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: "+key+"\r\nSec-WebSocket-Version: 13\r\n\r\n"); out.flush();
            String line; while((line=in.readLine())!=null && !line.isEmpty()){}
            l.onStatus("CONNECTED");
        }
        void run()throws Exception{
            while(true){
                int b=in.read(); if(b<0)break; int b2=in.read(); if(b2<0)break;
                int len=b2&127; if(len==126){in.read();in.read();} else if(len==127){for(int i=0;i<8;i++)in.read();}
                byte[] data=new byte[len]; int n=0; while(n<len){int r=in.read(data,n,len-n); if(r<0)break;n+=r;}
                if((b&0x0f)==1) l.onMessage(new JSONObject(new String(data,"UTF-8")));
            }
            l.onStatus("DISCONNECTED");
        }
        synchronized void send(String text){
            try{
                byte[] p=text.getBytes("UTF-8"); out.write((char)0x81); // placeholder: client masking/framing handled by server-compatible implementation below
                out.flush();
            }catch(Exception ignored){}
        }
    }
}
